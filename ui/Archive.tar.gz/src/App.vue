<script setup>
import { RouterLink, RouterView } from 'vue-router'
// import HelloWorld from './components/HelloWorld.vue'
</script>

<template>
    <h1 className="text-3xl font-bold">
      Hello world!
    </h1>
  <!-- <RouterView /> -->
</template>

