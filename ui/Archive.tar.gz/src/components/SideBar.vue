<template>
    <aside class="menu">
      <p class="menu-label">
        Navigation
      </p>
      <ul class="menu-list">
        <li><RouterLink to="/">Home</RouterLink></li>
        <li><RouterLink to="/transactions">Transactions</RouterLink></li>
      </ul>
    </aside>
  </template>
  
  <script setup>
  import { RouterLink } from 'vue-router';
  </script>
  
  <style scoped>
  .menu {
    width: 250px;
    height: 100vh;
    border-right: 1px solid #ccc;
    padding: 20px;
  }
  </style>
  